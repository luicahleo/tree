using TreeCore.Data;

namespace CapaNegocio
{
    public class MantenimientoEmplazamientosCorrectivosSeguimientosController : GeneralBaseController<MantenimientoEmplazamientosCorrectivosSeguimientos, TreeCoreContext>
    {
        public MantenimientoEmplazamientosCorrectivosSeguimientosController()
            : base()
        { }
	}
}