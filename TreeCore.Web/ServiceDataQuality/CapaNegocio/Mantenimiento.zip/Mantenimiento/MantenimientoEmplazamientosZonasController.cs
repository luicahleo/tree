using System;
using System.Data;
using System.Linq;
using Tree.Linq.GenericExtensions;
using TreeCore.Data;

namespace CapaNegocio
{
    public class MantenimientoEmplazamientosZonasController : GeneralBaseController<MantenimientoEmplazamientosZonas, TreeCoreContext>
    {
        public MantenimientoEmplazamientosZonasController()
            : base()
        { }

    }
}