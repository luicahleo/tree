﻿using System;
using System.Data;
using TreeCore.Data;
using System.Collections.Generic;
using Tree.Linq.GenericExtensions;
using System.Linq;

namespace CapaNegocio
{
    public class MantenimientoEmplazamientosEstadosSLAController : GeneralBaseController<MantenimientoEmplazamientosEstadosSLA, TreeCoreContext>
    {
        public MantenimientoEmplazamientosEstadosSLAController()
            : base()
        { }
    }
}